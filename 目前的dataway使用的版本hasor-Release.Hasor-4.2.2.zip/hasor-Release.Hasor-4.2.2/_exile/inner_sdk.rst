CollectionUdfSource
------------------------------------
集合函数库：``import 'net.hasor.dataql.sdk.CollectionUdfSource' as collect;``

DateTimeUdfSource
------------------------------------
时间函数库：``import 'net.hasor.dataql.sdk.DateTimeUdfSource' as time;``

IdentifierUdfSource
------------------------------------
ID函数库：``import 'net.hasor.dataql.sdk.IdentifierUdfSource' as ids;``

StateUdfSource
------------------------------------
状态函数库：``import 'net.hasor.dataql.sdk.StateUdfSource' as state;``

StringUdfSource
------------------------------------
字符串函数库：``import 'net.hasor.dataql.sdk.StringUdfSource' as string;``
