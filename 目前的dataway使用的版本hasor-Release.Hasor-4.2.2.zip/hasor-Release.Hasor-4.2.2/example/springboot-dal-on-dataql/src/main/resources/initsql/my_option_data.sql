insert into my_option ("id", "key", "value", "desc", "create_time", "modify_time")
values ('id_a', 'a', 'a', 'desc of a', now(), now());
insert into my_option ("id", "key", "value", "desc", "create_time", "modify_time")
values ('id_b', 'b', 'b', 'desc of b', now(), now());
