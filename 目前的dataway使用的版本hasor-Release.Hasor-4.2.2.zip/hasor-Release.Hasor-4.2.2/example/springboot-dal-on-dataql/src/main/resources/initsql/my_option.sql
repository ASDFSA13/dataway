CREATE TABLE my_option (
    "id"          varchar(50) NOT NULL,
    "key"         varchar(50) NOT NULL,
    "value"       varchar(50) NOT NULL,
    "desc"        varchar(50) NOT NULL,
    "create_time" TIMESTAMP   NOT NULL,
    "modify_time" TIMESTAMP   NOT NULL
)