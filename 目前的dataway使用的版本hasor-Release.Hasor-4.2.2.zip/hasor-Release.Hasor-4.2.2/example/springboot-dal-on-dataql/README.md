# 普通 SpringBoot 应用，数据库访问层使用 DataQL
