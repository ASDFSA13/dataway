# Hasor Commons 通用工具包

&emsp;&emsp; Hasor-Commons 存在的意义是为了减少外部依赖，因此大量工具方法都是直接从 Apache Commons 中移植过来。此外还有一些 Hasor 原生工具以及扩展的方法。

----------
## 主要内容
01. jetty-utils 中的 json 工具包，经过简化改造。位于：net.hasor.utils.json
02. asm源码，位于：net.hasor.utils.asm
03. convert源码，来源于 apache commons，位于：net.hasor.utils.convert。
04. 其它Utils，来源于 apache commons 以及平时沉淀。
